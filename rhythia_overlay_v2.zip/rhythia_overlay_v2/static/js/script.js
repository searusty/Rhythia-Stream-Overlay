// Stream overlay script
// Fetches data from data.json and updates the overlay elements.

(() => {
    // Parse query parameters once. Defined here to avoid temporal dead zone issues.
    const params = new URLSearchParams(window.location.search);

    // Helper to parse boolean-like URL parameters.
    function getBoolParam(name, defaultVal = true) {
        const val = params.get(name);
        if (val === null) return defaultVal;
        return !(val === '0' || (typeof val === 'string' && val.toLowerCase() === 'false') || (typeof val === 'string' && val.toLowerCase() === 'no'));
    }

    // Helper to read the first present key from a data object.
    function firstDefined(obj, keys, fallback = undefined) {
        for (const key of keys) {
            if (obj && obj[key] !== undefined && obj[key] !== null) {
                return obj[key];
            }
        }
        return fallback;
    }

    // Helper to format numbers for display.
    // For the leaderboard row, decimals > 0 produce a dot decimal and no thousand separators.
    // For the profile card, decimals = 0 will round to whole numbers with no grouping.
    function formatNumber(num, decimals = 0) {
        if (num === null || num === undefined || num === '' || isNaN(num)) return 'N/A';
        const n = typeof num === 'string' ? parseFloat(num) : num;
        const opts = {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals,
            useGrouping: false
        };
        return Number(n).toLocaleString('en-US', opts);
    }

    function decimalPlacesFor(value, maxDecimals = 2) {
        if (value === undefined || value === null || value === '' || isNaN(value)) return 0;
        const parts = String(value).split('.');
        if (parts.length !== 2) return 0;
        return Math.min(maxDecimals, parts[1].length);
    }

    function normalizeCurrentSpan(container, currentClass, newClass, oldClass) {
        let currentSpan = container.querySelector(`span.${currentClass}`);

        // Backward compatibility for older HTML that still uses class="current".
        if (!currentSpan) {
            currentSpan = container.querySelector('span.current');
            if (currentSpan) {
                currentSpan.classList.remove('current', newClass, oldClass);
                currentSpan.classList.add(currentClass);
            }
        }

        // If a previous animation was interrupted, prefer the newest visible span.
        const interruptedNewSpan = container.querySelector(`span.${newClass}`);
        if (interruptedNewSpan) {
            if (currentSpan && currentSpan !== interruptedNewSpan) currentSpan.remove();
            interruptedNewSpan.classList.remove(newClass, oldClass);
            interruptedNewSpan.classList.add(currentClass);
            currentSpan = interruptedNewSpan;
        }

        if (!currentSpan) {
            currentSpan = document.createElement('span');
            currentSpan.classList.add(currentClass);
            currentSpan.textContent = 'N/A';
            container.appendChild(currentSpan);
        }

        // Remove stale old/new spans so each field always has a clean stack.
        container.querySelectorAll(`span.${oldClass}, span.${newClass}`).forEach((span) => {
            if (span !== currentSpan) span.remove();
        });

        currentSpan.style.transition = '';
        currentSpan.style.transform = '';
        return currentSpan;
    }

    function animateRollingText(container, nextText, config) {
        if (!container) return;

        const currentClass = config.currentClass;
        const newClass = config.newClass;
        const oldClass = config.oldClass;
        const durationMs = config.durationMs || 600;
        const easing = config.easing || 'cubic-bezier(0.22, 1, 0.36, 1)';
        const text = nextText === undefined || nextText === null || nextText === '' ? 'N/A' : String(nextText);

        const currentSpan = normalizeCurrentSpan(container, currentClass, newClass, oldClass);

        // This is the important guard: unchanged fields do not animate.
        if (currentSpan.textContent === text && container.dataset.animatingTo !== text) {
            return;
        }
        if (container.dataset.animatingTo === text) {
            return;
        }

        const existingTimer = container.dataset.rollTimer;
        if (existingTimer) {
            window.clearTimeout(Number(existingTimer));
            delete container.dataset.rollTimer;
        }

        container.dataset.animatingTo = text;

        currentSpan.classList.remove(currentClass, newClass);
        currentSpan.classList.add(oldClass);
        currentSpan.style.transition = 'none';
        currentSpan.style.transform = 'translateY(0)';

        const newSpan = document.createElement('span');
        newSpan.classList.add(newClass);
        newSpan.textContent = text;
        newSpan.style.transition = 'none';
        newSpan.style.transform = 'translateY(100%)';
        container.appendChild(newSpan);

        // Force layout so the browser sees the starting position before animating.
        newSpan.offsetHeight;

        requestAnimationFrame(() => {
            currentSpan.style.transition = `transform ${durationMs}ms ${easing}`;
            newSpan.style.transition = `transform ${durationMs}ms ${easing}`;
            currentSpan.style.transform = 'translateY(-100%)';
            newSpan.style.transform = 'translateY(0)';
        });

        const timer = window.setTimeout(() => {
            currentSpan.remove();
            newSpan.classList.remove(newClass, oldClass);
            newSpan.classList.add(currentClass);
            newSpan.style.transition = '';
            newSpan.style.transform = '';
            delete container.dataset.animatingTo;
            delete container.dataset.rollTimer;
        }, durationMs + 80);

        container.dataset.rollTimer = String(timer);
    }

    // Minimal row animation path. This intentionally uses its own class names.
    function animateMinimalNumber(container, newValue, decimals = 0, prefix = '') {
        const formatted = prefix + formatNumber(newValue, decimals);
        animateRollingText(container, formatted, {
            currentClass: 'minimal-current',
            newClass: 'minimal-new',
            oldClass: 'minimal-old',
            durationMs: 560
        });
    }

    // Maximal card animation path. This intentionally uses its own class names.
    function animateMaximalNumber(container, newValue, decimals = 0, prefix = '') {
        const formatted = prefix + formatNumber(newValue, decimals);
        animateRollingText(container, formatted, {
            currentClass: 'maximal-current',
            newClass: 'maximal-new',
            oldClass: 'maximal-old',
            durationMs: 640
        });
    }

    // Track the last display mode applied. This ensures that manual updates
    // via updateOverlay do not inadvertently switch between minimal and
    // maximal views when displayMode is not provided.
    let currentMode = 'minimal';

    // Update the UI elements with new data.
    function updateUI(data) {
        if (!data) return;

        const errorContainer = document.getElementById('overlay-error');
        const minContainer = document.getElementById('minimal');
        const maxContainer = document.getElementById('maximal');

        // If an error was written into the data, display it and bail out.
        if (data.error) {
            if (errorContainer) {
                errorContainer.textContent = data.error;
                errorContainer.style.display = '';
            }
            if (minContainer) minContainer.style.display = 'none';
            if (maxContainer) maxContainer.style.display = 'none';
            return;
        }

        if (errorContainer) {
            errorContainer.textContent = '';
            errorContainer.style.display = 'none';
        }

        // If there is no data beyond the interval, show a waiting message.
        const keys = Object.keys(data);
        if (keys.length <= 2 && !data.rank && !data.skill_points && !data.rhythm_points) {
            if (errorContainer) {
                errorContainer.textContent = 'Waiting for data...';
                errorContainer.style.display = '';
            }
        }

        // Adjust polling interval if provided in data.
        if (data.interval) {
            const newIntervalMs = data.interval * 1000;
            if (newIntervalMs !== refreshInterval) {
                refreshInterval = newIntervalMs;
                clearInterval(fetchTimer);
                fetchTimer = setInterval(fetchData, refreshInterval);
            }
        }

        // Determine display mode. When no displayMode is provided, retain the last-used mode.
        let mode;
        if (data.displayMode) {
            mode = (data.displayMode || 'minimal').toLowerCase();
            currentMode = mode;
        } else {
            mode = currentMode;
        }

        if (mode === 'minimal') {
            if (minContainer) minContainer.style.display = 'grid';
            if (maxContainer) maxContainer.style.display = 'none';
        } else {
            if (minContainer) minContainer.style.display = 'none';
            if (maxContainer) maxContainer.style.display = 'flex';
        }

        // Feature toggles. URL params override data.features.
        const feats = data.features || {};
        const effectiveShowAvatar = getBoolParam('showAvatar', feats.showAvatar !== undefined ? feats.showAvatar : true);
        const effectiveShowFlag = getBoolParam('showFlag', feats.showFlag !== undefined ? feats.showFlag : true);
        const effectiveShowUsername = getBoolParam('showUsername', feats.showUsername !== undefined ? feats.showUsername : true);
        const effectiveShowRank = getBoolParam('showRank', feats.showRank !== undefined ? feats.showRank : true);
        const effectiveShowSkillPoints = getBoolParam('showSkillPoints', feats.showSkillPoints !== undefined ? feats.showSkillPoints : true);
        const effectiveShowPlays = getBoolParam('showPlays', feats.showPlays !== undefined ? feats.showPlays : true);
        const effectiveShowSince = getBoolParam('showSince', feats.showSince !== undefined ? feats.showSince : true);
        const effectiveShowTitle = getBoolParam('showTitle', feats.showTitle !== undefined ? feats.showTitle : true);
        const effectiveShowGlobalRank = getBoolParam('showGlobalRank', feats.showGlobalRank !== undefined ? feats.showGlobalRank : true);
        const effectiveShowCountryRank = getBoolParam('showCountryRank', feats.showCountryRank !== undefined ? feats.showCountryRank : true);
        const effectiveShowRhythmPoints = getBoolParam('showRhythmPoints', feats.showRhythmPoints !== undefined ? feats.showRhythmPoints : true);

        function updateMinimal() {
            const minRank = document.getElementById('min_rank');
            const minFlag = document.getElementById('min_flag');
            const minUsername = document.getElementById('min_username');
            const minTitleIcon = document.getElementById('min_title_icon');
            const minSkillPoints = document.getElementById('min_skill_points');
            const minPlays = document.getElementById('min_plays');
            if (!minRank) return;

            minRank.style.display = effectiveShowRank ? '' : 'none';
            if (minFlag) minFlag.style.display = effectiveShowFlag ? '' : 'none';
            if (minUsername) minUsername.style.display = effectiveShowUsername ? '' : 'none';
            if (minTitleIcon) minTitleIcon.style.display = effectiveShowTitle && data.title_icon ? '' : 'none';
            if (minSkillPoints) minSkillPoints.style.display = effectiveShowSkillPoints ? '' : 'none';
            if (minPlays) minPlays.style.display = effectiveShowPlays ? '' : 'none';

            if (effectiveShowRank) {
                animateMinimalNumber(minRank, firstDefined(data, ['rank', 'global_rank']), 0, '#');
            }
            if (effectiveShowFlag && minFlag && data.flag) {
                minFlag.src = `https://flagcdn.com/h20/${data.flag.toLowerCase()}.png`;
            }
            if (effectiveShowUsername && minUsername) {
                minUsername.textContent = firstDefined(data, ['username', 'name'], '');
            }
            if (effectiveShowTitle && minTitleIcon && data.title_icon) {
                minTitleIcon.src = data.title_icon;
                minTitleIcon.alt = data.title_name || '';
            }
            if (effectiveShowSkillPoints && minSkillPoints) {
                const skillPoints = firstDefined(data, ['skill_points', 'rhythm_points']);
                animateMinimalNumber(minSkillPoints, skillPoints, decimalPlacesFor(skillPoints, 2));
            }
            if (effectiveShowPlays && minPlays) {
                animateMinimalNumber(minPlays, firstDefined(data, ['play_count', 'plays']), 0);
            }
        }

        function updateMaximal() {
            const maxAvatar = document.getElementById('max_avatar');
            const maxUsername = document.getElementById('max_username');
            const maxSince = document.getElementById('max_since');
            const maxTitleBox = document.getElementById('max_title_box');
            const maxTitleIcon = document.getElementById('max_title_icon');
            const maxTitleName = document.getElementById('max_title_name');
            const maxGlobalBox = document.getElementById('max_global_box');
            const maxCountryBox = document.getElementById('max_country_box');
            const maxPointsBox = document.getElementById('max_points_box');
            const maxPlaysBox = document.getElementById('max_plays_box');
            const maxGlobalRank = document.getElementById('max_global_rank');
            const maxCountryRank = document.getElementById('max_country_rank');
            const maxRhythmPoints = document.getElementById('max_rhythm_points');
            const maxPlays = document.getElementById('max_plays');
            const maxFlag = document.getElementById('max_flag');
            if (!maxUsername) return;

            if (maxAvatar) {
                maxAvatar.style.display = effectiveShowAvatar ? '' : 'none';
                if (effectiveShowAvatar && data.avatar_url) {
                    maxAvatar.src = data.avatar_url;
                }
            }

            if (maxUsername) {
                maxUsername.style.display = effectiveShowUsername ? '' : 'none';
                if (effectiveShowUsername) {
                    maxUsername.textContent = firstDefined(data, ['username', 'name'], '');
                }
            }

            if (maxSince) {
                maxSince.style.display = effectiveShowSince && data.since ? '' : 'none';
                if (effectiveShowSince && data.since) {
                    maxSince.textContent = `Here since ${data.since}`;
                }
            }

            if (maxFlag) {
                maxFlag.style.display = effectiveShowFlag ? '' : 'none';
                if (effectiveShowFlag && data.flag) {
                    maxFlag.src = `https://flagcdn.com/h20/${data.flag.toLowerCase()}.png`;
                }
            }

            if (maxTitleBox) {
                maxTitleBox.style.display = effectiveShowTitle ? '' : 'none';
            }
            if (maxTitleIcon) {
                maxTitleIcon.style.display = effectiveShowTitle && data.title_icon ? '' : 'none';
                if (effectiveShowTitle && data.title_icon) {
                    maxTitleIcon.src = data.title_icon;
                    maxTitleIcon.alt = data.title_name || '';
                }
            }
            if (maxTitleName) {
                maxTitleName.style.display = effectiveShowTitle && data.title_name ? '' : 'none';
                if (effectiveShowTitle && data.title_name) {
                    maxTitleName.textContent = data.title_name;
                }
            }

            const leftSection = document.querySelector('.left-section');
            const showLeftSection = effectiveShowAvatar || effectiveShowFlag || effectiveShowUsername || (effectiveShowSince && !!data.since);
            if (leftSection) {
                leftSection.style.display = showLeftSection ? 'flex' : 'none';
            }

            const statsRow = document.querySelector('.stats-row');
            if (statsRow) {
                statsRow.style.maxWidth = showLeftSection ? '' : '100%';
            }

            if (maxGlobalBox) maxGlobalBox.style.display = effectiveShowGlobalRank ? '' : 'none';
            if (maxCountryBox) maxCountryBox.style.display = effectiveShowCountryRank ? '' : 'none';
            if (maxPointsBox) maxPointsBox.style.display = effectiveShowRhythmPoints ? '' : 'none';
            if (maxPlaysBox) maxPlaysBox.style.display = effectiveShowPlays ? '' : 'none';

            if (maxGlobalRank && effectiveShowGlobalRank) {
                animateMaximalNumber(maxGlobalRank, firstDefined(data, ['global_rank', 'rank']), 0, '#');
            }
            if (maxCountryRank && effectiveShowCountryRank) {
                animateMaximalNumber(maxCountryRank, firstDefined(data, ['country_rank']), 0, '#');
            }
            if (maxRhythmPoints && effectiveShowRhythmPoints) {
                // Some producers send skill_points, others send rhythm_points. Accept both.
                animateMaximalNumber(maxRhythmPoints, firstDefined(data, ['rhythm_points', 'skill_points']), 0);
            }
            if (maxPlays && effectiveShowPlays) {
                animateMaximalNumber(maxPlays, firstDefined(data, ['play_count', 'plays']), 0);
            }
        }

        if (mode === 'minimal') {
            updateMinimal();
        } else {
            updateMaximal();
        }
    }

    // Fetch the JSON data and update UI.
    function fetchData() {
        fetch('data.json?cacheBust=' + Date.now())
            .then(response => response.json())
            .then(json => {
                updateUI(json);
            })
            .catch(err => {
                console.error('Failed to fetch overlay data:', err);
                updateUI({ error: 'Failed to fetch overlay data' });
            });
    }

    let refreshInterval = parseInt(params.get('interval'), 10) || 10000;
    let fetchTimer;

    function startFetching() {
        fetchData();
        fetchTimer = setInterval(fetchData, refreshInterval);
    }

    startFetching();

    // Expose a helper on the window for testing. You can call updateOverlay({ ... })
    // from the browser console to update the overlay manually with arbitrary values.
    window.updateOverlay = function(data) {
        updateUI(data || {});
    };
})();
